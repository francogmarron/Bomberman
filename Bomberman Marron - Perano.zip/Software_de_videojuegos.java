public class Software_de_videojuegos {
    public Software_de_videojuegos(){

    }

    public void Elegir_juego(){
        
    }

}