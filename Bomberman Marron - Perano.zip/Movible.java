


public interface Movible {
    public void Mover();
}
