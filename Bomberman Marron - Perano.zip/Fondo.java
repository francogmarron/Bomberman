public class Fondo extends ObjetoGrafico{

	public Fondo(String img) {
		super(img);
		setPosicion(0,0); // El fondo es una imagen estatica, pero muy grande
	}

}