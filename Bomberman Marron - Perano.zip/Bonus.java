
public class Bonus extends ObjetoGrafico{
    public Bonus(String img, double X, double Y){
        super(img);
        this.setPosicion(X, Y);
        this.setAncho(10, 10);
    }

    public void activarEfecto(){
        
    }

}